"""Scripts package for AyurWell repository."""
